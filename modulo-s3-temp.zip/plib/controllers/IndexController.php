<?php
class IndexController extends pm_Controller_Action
{
    public function indexAction()
    {
        $this->view->pageTitle = 'Respaldo Modular S3';

        $form = new pm_Form_Simple();
        $form->addElement('text', 'backup_time', [
            'label' => 'Hora de ejecución diaria (HH:MM)',
            'value' => pm_Settings::get('backup_time', '23:00'),
            'required' => true,
        ]);

        $form->addElement('select', 'cycle_period', [
            'label' => 'Frecuencia del respaldo Full',
            'multiOptions' => [
                '7:1W' => 'Cada 7 días (Full-1W / Inc-1W)',
                '14:2W' => 'Cada 14 días (Full-2W / Inc-2W)',
                '21:3W' => 'Cada 21 días (Full-3W / Inc-3W)',
                '30:4W' => 'Cada 30 días (Full-4W / Inc-4W)',
            ],
            'value' => pm_Settings::get('cycle_period', '21:3W'),
            'required' => true,
        ]);

        $form->addElement('select', 'retention_period', [
            'label' => 'Periodo de retención en S3 (Ciclo + X días)',
            'multiOptions' => [
                '7' => '+ 7 días (Ahorro máximo)',
                '14' => '+ 14 días (Dos semanas extra)',
                '21' => '+ 21 días',
                '30' => '+ 30 días (Mensual)',
                '45' => '+ 45 días',
                '60' => '+ 60 días',
                '90' => '+ 90 días (Trimestral)',
            ],
            'value' => pm_Settings::get('retention_period', '7'),
            'required' => true,
        ]);

        $form->addControlButtons([
            'cancelLink' => pm_Context::getModulesListUrl(),
        ]);

        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $time = trim($form->getValue('backup_time'));
            pm_Settings::set('backup_time', $time);
            pm_Settings::set('cycle_period', $form->getValue('cycle_period'));
            pm_Settings::set('retention_period', $form->getValue('retention_period'));

            $this->_status->addInfo('Configuración y políticas de retención guardadas correctamente.');
            $this->_helper->json(['redirect' => pm_Context::getActionUrl('index', 'index')]);
        }

        $this->view->form = $form;
    }
}
