<?php
pm_Context::init('respaldo-modular');

// 1. Inicializar valores por defecto si no existen
if (!pm_Settings::get('backup_time')) {
    pm_Settings::set('backup_time', '23:00');
}
if (!pm_Settings::get('cycle_period')) {
    pm_Settings::set('cycle_period', '21:3W');
}
if (!pm_Settings::get('retention_period')) {
    pm_Settings::set('retention_period', '7');
}

// 2. Crear el cron de sistema con privilegios de root
$cronPath = '/etc/cron.d/respaldo-modular';
$scriptPath = pm_Context::getPlibDir() . 'scripts/runner.php';

$cronContent = <<<CRON
SHELL=/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin

# Disparador automatizado de Respaldo Modular S3
* * * * * root /usr/bin/sw-engine {$scriptPath} --check-time >> /var/log/plesk-backups.log 2>&1

CRON;

file_put_contents($cronPath, $cronContent);
chmod($cronPath, 0644);
chown($cronPath, 'root');
