<?php
$cronPath = '/etc/cron.d/respaldo-modular';
if (file_exists($cronPath)) {
    @unlink($cronPath);
}
