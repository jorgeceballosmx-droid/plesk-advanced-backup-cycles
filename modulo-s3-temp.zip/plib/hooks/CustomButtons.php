<?php
class Modules_RespaldoModular_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        return [
            [
                'place' => self::PLACE_ADMIN_NAVIGATION,
                'title' => 'Respaldo Modular',
                'description' => 'Configurador de respaldos secuenciales S3',
                'icon' => pm_Context::getBaseUrl() . 'icon_16.png',
                'link' => pm_Context::getActionUrl('index', 'index'),
            ],
            [
                'place' => self::PLACE_ADMIN_TOOLS_AND_SETTINGS,
                'title' => 'Respaldo Modular',
                'description' => 'Configura horarios y frecuencias para respaldos secuenciales a S3',
                'icon' => pm_Context::getBaseUrl() . 'icon_16.png',
                'link' => pm_Context::getActionUrl('index', 'index'),
            ],
        ];
    }
}
