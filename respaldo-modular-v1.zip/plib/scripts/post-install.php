<?php
ini_set('include_path', '/usr/local/psa/admin/plib' . PATH_SEPARATOR . ini_get('include_path'));
if (!class_exists('Loader', false) && file_exists('/usr/local/psa/admin/plib/Loader.php')) {
    require_once '/usr/local/psa/admin/plib/Loader.php';
}
if (!class_exists('pm_Loader', false) && file_exists('/usr/local/psa/admin/plib/sdk.php')) {
    require_once '/usr/local/psa/admin/plib/sdk.php';
}

pm_Context::init('respaldo-modular');

if (!pm_Settings::get('backup_time')) {
    pm_Settings::set('backup_time', '23:00');
}
if (!pm_Settings::get('cycle_period')) {
    pm_Settings::set('cycle_period', '21:3W');
}
if (!pm_Settings::get('retention_period')) {
    pm_Settings::set('retention_period', '7');
}

$cronPath = '/etc/cron.d/respaldo-modular';
$scriptPath = pm_Context::getPlibDir() . 'scripts/runner.php';

$cronContent = <<<CRON
SHELL=/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin

# Disparador automatizado de Respaldo Modular S3
* * * * * root /usr/local/psa/admin/bin/php -dauto_prepend_file=sdk.php {$scriptPath} --check-time >> /var/log/plesk-backups.log 2>&1

CRON;

file_put_contents($cronPath, $cronContent);
chmod($cronPath, 0644);
chown($cronPath, 'root');
