<?php
// Cargar autoloader base del SDK de Plesk
ini_set('include_path', '/usr/local/psa/admin/plib' . PATH_SEPARATOR . ini_get('include_path'));
if (!class_exists('Loader', false) && file_exists('/usr/local/psa/admin/plib/Loader.php')) {
    require_once '/usr/local/psa/admin/plib/Loader.php';
}
if (!class_exists('pm_Loader', false) && file_exists('/usr/local/psa/admin/plib/sdk.php')) {
    require_once '/usr/local/psa/admin/plib/sdk.php';
}

pm_Context::init('respaldo-modular');

// 1. Validar hora de ejecución
$targetTime = pm_Settings::get('backup_time', '23:00');
$currentTime = date('H:i');

if (isset($argv[1]) && $argv[1] === '--check-time') {
    if ($currentTime !== $targetTime) {
        exit(0);
    }
    $today = date('Y-m-d');
    if (pm_Settings::get('last_run_date') === $today) {
        exit(0);
    }
    pm_Settings::set('last_run_date', $today);
}

// 2. Parámetros del ciclo y cálculo de retención
$cycleSetting = pm_Settings::get('cycle_period', '21:3W');
list($cycleDays, $suffix) = explode(':', $cycleSetting);
$cycleDays = (int) $cycleDays;

$retentionDays = (int) pm_Settings::get('retention_period', '7');
$keepBackups = (int) ceil(($cycleDays + $retentionDays) / $cycleDays);

// 3. Evaluar rotación: si nunca ha corrido en el servidor, forzar FULL inicial
$lastFullDate = pm_Settings::get('last_full_date');
if (empty($lastFullDate)) {
    $isFullDay = true;
} else {
    $daysSinceFull = (int) ((time() - strtotime($lastFullDate)) / 86400);
    $isFullDay = ($daysSinceFull >= $cycleDays);
}

$prefix = "Full-{$suffix}";
$description = $isFullDay ? "Full-{$suffix}" : "Inc-{$suffix}";
$mode = $isFullDay ? "COMPLETO" : "INCREMENTAL";

echo "=== Inicio {$mode} " . date('Y-m-d H:i:s') . " (Ciclo: {$suffix}, Retención: {$keepBackups} Generaciones) ===\n";

$db = pm_Bootstrap::getDbAdapter();
$domains = $db->fetchAll("SELECT id, name FROM domains WHERE status = 0 AND webspace_id = 0");

foreach ($domains as $domain) {
    $domId = $domain['id'];
    $domName = $domain['name'];

    echo "Procesando {$mode} para {$domName} ({$domId})...\n";

    $args = [
        '--domains-name', $domName,
        '-description', $description,
        '-prefix', $prefix,
        '-output-file', "ext://s3-backup/subscription/{$domId}/"
    ];

    if (!$isFullDay) {
        $args[] = '-incremental';
    } else {
        $args[] = '-keep-backups';
        $args[] = (string) $keepBackups;
    }

    try {
        pm_ApiCli::call('pleskbackup', $args);
        echo "Exito para {$domName}\n";
    } catch (Exception $e) {
        echo "Error en {$domName}: " . $e->getMessage() . "\n";
    }
}

if ($isFullDay) {
    pm_Settings::set('last_full_date', date('Y-m-d'));
}

echo "=== Fin {$mode} " . date('Y-m-d H:i:s') . " ===\n";
